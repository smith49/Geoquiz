package com.example.geoquizassignment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.google.android.material.bottomsheet.BottomSheetDialog;

import java.util.ArrayList;
import java.util.Random;

public class MainActivity extends AppCompatActivity {
    private TextView question,questionno;
    private Button option1,option2,option3,option4,next,previous;
    private ArrayList<QuizModal> quizModalArrayList;
    Random random;
    int CurrScore=0,questattempt=1, currentPos;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        question = findViewById(R.id.Questionattempted);
        questionno = findViewById(R.id.Quest);
        option1 = findViewById(R.id.idBtnOption1);
        option2 = findViewById(R.id.idBtnOption2);
        option3 = findViewById(R.id.idBtnOption3);
        option4 = findViewById(R.id.idBtnOption4);
        next= findViewById(R.id.idBtnNext);
        previous= findViewById(R.id.idBtnPrevious);
        quizModalArrayList = new ArrayList<>();
        random = new Random();
        getQuiz(quizModalArrayList);
        currentPos = random.nextInt(quizModalArrayList.size());
        setDataToViews(currentPos);
        option1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (quizModalArrayList.get(currentPos).getAnswer().trim().toLowerCase().equals(option1.getText().toString().toLowerCase())) {
                    CurrScore++;
                }
                questattempt++;
                currentPos = random.nextInt(quizModalArrayList.size());
                setDataToViews(currentPos);
            }
        });
        option2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (quizModalArrayList.get(currentPos).getAnswer().trim().toLowerCase().equals(option2.getText().toString().toLowerCase())) {
                    CurrScore++;
                }
                questattempt++;
                currentPos = random.nextInt(quizModalArrayList.size());
                setDataToViews(currentPos);
            }
        });
        option3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (quizModalArrayList.get(currentPos).getAnswer().trim().toLowerCase().equals(option3.getText().toString().toLowerCase())) {
                    CurrScore++;
                }
                questattempt++;
                currentPos = random.nextInt(quizModalArrayList.size());
                setDataToViews(currentPos);
            }
        });
        option4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (quizModalArrayList.get(currentPos).getAnswer().trim().toLowerCase().equals(option4.getText().toString().toLowerCase())) {
                    CurrScore++;
                }

            }
        });
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                questattempt++;
                currentPos = random.nextInt(quizModalArrayList.size());
                setDataToViews(currentPos);
            }
        });
        previous.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                questattempt--;
                currentPos = random.nextInt(quizModalArrayList.size());
                setDataToViews(currentPos);
            }
        });

    }
    private void showbottomsheet(){
        BottomSheetDialog bottomSheetDialog=new BottomSheetDialog(MainActivity.this);
        View bottomSheetView= LayoutInflater.from(getApplicationContext()).inflate(R.layout.score_bottom_sheet,(LinearLayout)findViewById(R.id.idLLScore));
        TextView scoreTV=bottomSheetView.findViewById(R.id.idTVScore);
        Button restartQuizBtn=bottomSheetView.findViewById(R.id.idBtnRestart);
        scoreTV.setText("Your score is \n"+CurrScore+"/5");
        restartQuizBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                currentPos=random.nextInt(quizModalArrayList.size());
                setDataToViews(currentPos);
                questattempt=1;
                CurrScore=0;
                bottomSheetDialog.dismiss();
            }
        });
        bottomSheetDialog.setCancelable(false);
        bottomSheetDialog.setContentView(bottomSheetView);
        bottomSheetDialog.show();


    }
    private void setDataToViews ( int currentPos) {
        questionno.setText("Questions Attempted: " + questattempt + "/5");
        if(questattempt==5){
            showbottomsheet();
        }
        else{
            question.setText(quizModalArrayList.get(currentPos).getQuestion());
            option1.setText(quizModalArrayList.get(currentPos).getOption1());
            option2.setText(quizModalArrayList.get(currentPos).getOption2());
            option3.setText(quizModalArrayList.get(currentPos).getOption3());
            option4.setText(quizModalArrayList.get(currentPos).getOption4());
        }


    }


    private void getQuiz(ArrayList<QuizModal> quizModalArrayList ) {
        quizModalArrayList.add(new QuizModal(question"Which crop is sown on the largest area in India?", option1"Rice",option2"Wheat",option3"Sugarcane",option4"Maize",answer"Rice"));
        quizModalArrayList.add(new QuizModal(question"Galileo was an astronomer who discovered?", option1"Telescope",option2 "Satellites in Jupiter", option3"Pendulum Movement", option4"All of the above", "Sat"));
        quizModalArrayList.add(new QuizModal(question"What is the largest cricket stadium in the world?", option1"Eden Gardens", option2"Narendra Modi Stadium ",option3 "Lords", option4"Oval", "Narendra Modi Stadium"));
        quizModalArrayList.add(new QuizModal(question"Corey Anderson scored fastest ODI century against?", option1"India", option2"West Indies", option3"Pakistan", option4"Austrailia", "New Zealand"));
        quizModalArrayList.add(new QuizModal(question"Who did England beat in the final of the 2019 Cricket World Cup?", option1"Australia",option2 "New Zealand",option3 "Pakistan",option4 "South Africa", "New Zealand"));

    }
}

